#ifdef IS_IN_ldconfig
# include <sysdeps/i386/dl-procinfo.c>
#else
# include <sysdeps/generic/dl-procinfo.c>
#endif
