/* bits/fcntl.h is architecture specific.  */
#error "This file must be supplied by every Linux architecture."

