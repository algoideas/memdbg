#include "../i386/get_clockfreq.c"
