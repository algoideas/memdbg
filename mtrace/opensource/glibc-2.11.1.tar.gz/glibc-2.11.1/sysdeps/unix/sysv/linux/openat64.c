#define OPENAT openat64
#define __OPENAT_2 __openat64_2
#define MORE_OFLAGS O_LARGEFILE

#include "openat.c"
