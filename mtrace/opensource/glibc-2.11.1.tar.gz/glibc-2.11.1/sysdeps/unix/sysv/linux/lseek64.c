/* We don't need a definition since the llseek function is what we need.  */
