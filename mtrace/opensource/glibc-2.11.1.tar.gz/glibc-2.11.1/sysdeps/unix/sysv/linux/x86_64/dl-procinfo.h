#ifdef IS_IN_ldconfig
# include <sysdeps/unix/sysv/linux/i386/dl-procinfo.h>
#else
# include <sysdeps/generic/dl-procinfo.h>
#endif
