/* We need this file since otherwise `signal' would be handled as a
   system call.  */
#include <sysdeps/posix/signal.c>
