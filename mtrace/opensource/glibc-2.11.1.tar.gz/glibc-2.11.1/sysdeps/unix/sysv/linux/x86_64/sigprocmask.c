#include <sysdeps/unix/sysv/linux/ia64/sigprocmask.c>
