/* Linux defines the profil system call but doesn't actually implement
   it.  Use the generic posix implementation.  */
#include <sysdeps/posix/profil.c>
