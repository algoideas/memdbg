#include <sysdeps/unix/sysv/linux/ia64/sigpending.c>
