#include <sysdeps/unix/bsd/ualarm.c>
