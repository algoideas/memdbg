#define SET_PROCEDURE 1
#include "gethostid.c"
