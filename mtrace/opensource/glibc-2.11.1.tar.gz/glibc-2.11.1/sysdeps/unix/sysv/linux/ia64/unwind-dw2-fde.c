/* Linux/ia64 does not need unwind table registry. */
