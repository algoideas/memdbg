#define USE_AS_STRCASESTR
#define STRSTR_SSE42 __strcasestr_sse42
#include "strstr.c"
