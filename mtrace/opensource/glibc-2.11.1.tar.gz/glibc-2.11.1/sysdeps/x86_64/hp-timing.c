/* We can use the i686 implementation without changes.  */
#include <sysdeps/i386/i686/hp-timing.c>
