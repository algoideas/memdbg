#include "../i386/ldbl2mpn.c"
