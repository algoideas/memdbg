/* __clz_tab not needed on x86-64.  */
