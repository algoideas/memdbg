#include <sysdeps/i386/fpu/s_significandl.c>
