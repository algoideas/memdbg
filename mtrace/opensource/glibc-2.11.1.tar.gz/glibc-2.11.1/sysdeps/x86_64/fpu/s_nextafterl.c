#include <sysdeps/i386/fpu/s_nextafterl.c>
